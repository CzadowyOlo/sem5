/*
 * Kod maszyny wirtualnej do projektu z JFTT2022
 *
 * Autor: Maciek Gębala
 * http://ki.pwr.edu.pl/gebala/
 * 2022-11-22
*/


----------------------------------------
Narzędzia:
bison (GNU Bison) 3.8.2
flex 2.6.4
GNU Make 4.3
g++ 11.3.0

libcln-dev 1.3.6

----------------------------------------
Pliki:
ReadMe.txt
Makefile
colors.hh
instructions.hh
lexer.l
parser.y
mw.cc
mw-cln.cc
main.cc

