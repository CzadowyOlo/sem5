# Aleksander Głowacki 261702
include("zad1.jl")
using .Interpolacja
using Plots

f = x -> abs(x)
g = x -> 1 / (1 + x^2)

for n in [5, 10, 15]
    plot_f = rysujNnfx2(f, -1., 1., n)
    plot_g = rysujNnfx2(g, -5., 5., n)
    savefig(plot_f, "z6f_$n.png")
    savefig(plot_g, "z6g_$n.png")
end
